import React, { useState, useRef, useEffect, useMemo } from 'react';
import { Canvas, useFrame, useThree } from '@react-three/fiber';
import { OrbitControls, PerspectiveCamera, Environment, ContactShadows } from '@react-three/drei';
import * as THREE from 'three';
import { motion, AnimatePresence } from 'motion/react';
import { RotateCcw, Shuffle, Trophy, HelpCircle, Settings2 } from 'lucide-react';

// --- Types ---
type Face = 'U' | 'D' | 'L' | 'R' | 'F' | 'B';

interface CubieState {
  position: [number, number, number];
  initialPosition: [number, number, number];
  rotation: THREE.Quaternion;
  id: string;
}

// --- Constants ---
const COLORS = {
  U: '#ffffff', // White
  D: '#ffff00', // Yellow
  L: '#ff8800', // Orange
  R: '#ff0000', // Red
  F: '#00ff00', // Green
  B: '#0000ff', // Blue
  internal: '#111111',
};

const FACE_VECTORS: Record<Face, THREE.Vector3> = {
  U: new THREE.Vector3(0, 1, 0),
  D: new THREE.Vector3(0, -1, 0),
  L: new THREE.Vector3(-1, 0, 0),
  R: new THREE.Vector3(1, 0, 0),
  F: new THREE.Vector3(0, 0, 1),
  B: new THREE.Vector3(0, 0, -1),
};

// --- Components ---

const Cubie = ({ initialPosition }: { initialPosition: [number, number, number] }) => {
  // Initial setup for colors based on initial position
  const materials = useMemo(() => {
    return [
      new THREE.MeshStandardMaterial({ color: initialPosition[0] === 1 ? COLORS.R : COLORS.internal }), // Right
      new THREE.MeshStandardMaterial({ color: initialPosition[0] === -1 ? COLORS.L : COLORS.internal }), // Left
      new THREE.MeshStandardMaterial({ color: initialPosition[1] === 1 ? COLORS.U : COLORS.internal }), // Up
      new THREE.MeshStandardMaterial({ color: initialPosition[1] === -1 ? COLORS.D : COLORS.internal }), // Down
      new THREE.MeshStandardMaterial({ color: initialPosition[2] === 1 ? COLORS.F : COLORS.internal }), // Front
      new THREE.MeshStandardMaterial({ color: initialPosition[2] === -1 ? COLORS.B : COLORS.internal }), // Back
    ];
  }, [initialPosition]);

  return (
    <>
      <mesh material={materials}>
        <boxGeometry args={[0.95, 0.95, 0.95]} />
      </mesh>
      {/* Black edges/border effect */}
      <mesh>
        <boxGeometry args={[0.96, 0.96, 0.96]} />
        <meshStandardMaterial color="#000000" wireframe />
      </mesh>
    </>
  );
};

const RubiksCube = ({ 
  scrambleTrigger, 
  resetTrigger,
  onMove,
  onSolved,
  orbitRef
}: { 
  scrambleTrigger: number, 
  resetTrigger: number,
  onMove: () => void,
  onSolved: (solved: boolean) => void,
  orbitRef: React.RefObject<any>
}) => {
  const [cubies, setCubies] = useState<CubieState[]>(() => {
    const initial: CubieState[] = [];
    for (let x = -1; x <= 1; x++) {
      for (let y = -1; y <= 1; y++) {
        for (let z = -1; z <= 1; z++) {
          if (x === 0 && y === 0 && z === 0) continue;
          initial.push({
            position: [x, y, z],
            initialPosition: [x, y, z],
            rotation: new THREE.Quaternion(),
            id: `${x}${y}${z}`,
          });
        }
      }
    }
    return initial;
  });

  const [animating, setAnimating] = useState(false);
  const [activeRotation, setActiveRotation] = useState<{
    axis: THREE.Vector3;
    layer: number;
    angle: number;
  } | null>(null);
  const [isSolved, setIsSolved] = useState(false);
  const { camera } = useThree();

  useFrame(() => {
    if (orbitRef.current) orbitRef.current.update();
  });

  const checkSolved = (currentCubies: CubieState[]) => {
    // A cube is solved if all cubies have the same rotation quaternion
    // (or rotations that result in the same visual alignment)
    const firstRot = currentCubies[0].rotation;
    for (let i = 1; i < currentCubies.length; i++) {
      const q1 = firstRot;
      const q2 = currentCubies[i].rotation;
      // Compare quaternions (q and -q represent the same rotation)
      const dot = Math.abs(q1.x * q2.x + q1.y * q2.y + q1.z * q2.z + q1.w * q2.w);
      if (dot < 0.999) return false;
    }
    return true;
  };

  const rotateFace = (axis: THREE.Vector3, layer: number, clockwise: boolean = true) => {
    if (animating) return;
    setAnimating(true);

    const targetAngle = (clockwise ? -Math.PI / 2 : Math.PI / 2);
    const duration = 200;
    const start = performance.now();

    const animate = (time: number) => {
      const elapsed = time - start;
      const progress = Math.min(elapsed / duration, 1);
      // Easing function
      const ease = progress === 1 ? 1 : 1 - Math.pow(2, -10 * progress);
      
      setActiveRotation({ axis, layer, angle: targetAngle * ease });

      if (progress < 1) {
        requestAnimationFrame(animate);
      } else {
        const finalRotation = new THREE.Quaternion().setFromAxisAngle(axis, targetAngle);
        
        setCubies(prev => {
          const next = prev.map(c => {
            const pos = new THREE.Vector3(...c.position);
            if (Math.abs(pos.dot(axis) - layer) < 0.1) {
              const newPos = pos.clone().applyQuaternion(finalRotation);
              newPos.x = Math.round(newPos.x);
              newPos.y = Math.round(newPos.y);
              newPos.z = Math.round(newPos.z);
              const newRot = finalRotation.clone().multiply(c.rotation);
              return { 
                ...c, 
                position: [newPos.x, newPos.y, newPos.z] as [number, number, number], 
                rotation: newRot 
              };
            }
            return c;
          });
          
          if (checkSolved(next)) {
            setIsSolved(true);
            onSolved(true);
          } else {
            setIsSolved(false);
            onSolved(false);
          }
          
          return next;
        });
        setActiveRotation(null);
        setAnimating(false);
        onMove();
      }
    };

    requestAnimationFrame(animate);
  };

  const handlePointerDown = (e: any) => {
    e.stopPropagation();
    if (animating) return;
    
    if (orbitRef.current) {
      orbitRef.current.enabled = false;
      orbitRef.current.autoRotate = false;
    }
    
    const startPos = new THREE.Vector2(e.clientX, e.clientY);
    const cubieId = e.object.parent.userData.id;
    const faceNormal = e.face.normal.clone().applyQuaternion(e.object.parent.quaternion);

    const onPointerUpWindow = (upEvent: PointerEvent) => {
      if (orbitRef.current) {
        orbitRef.current.enabled = true;
        orbitRef.current.autoRotate = true;
      }
      window.removeEventListener('pointerup', onPointerUpWindow);

      const delta = new THREE.Vector2(upEvent.clientX, upEvent.clientY).sub(startPos);
      if (delta.length() < 15) return; // Deadzone

      const cubie = cubies.find(c => c.id === cubieId);
      if (!cubie) return;

      const moveDir = new THREE.Vector3(delta.x, -delta.y, 0).normalize();
      const camRight = new THREE.Vector3(1, 0, 0).applyQuaternion(camera.quaternion);
      const camUp = new THREE.Vector3(0, 1, 0).applyQuaternion(camera.quaternion);
      const worldMoveDir = camRight.clone().multiplyScalar(moveDir.x).add(camUp.clone().multiplyScalar(moveDir.y));
      
      const rotationAxis = new THREE.Vector3().crossVectors(faceNormal, worldMoveDir).normalize();
      
      const axes = [
        new THREE.Vector3(1,0,0), new THREE.Vector3(-1,0,0), 
        new THREE.Vector3(0,1,0), new THREE.Vector3(0,-1,0), 
        new THREE.Vector3(0,0,1), new THREE.Vector3(0,0,-1)
      ];
      
      let bestAxis = axes[0];
      let maxDot = -Infinity;
      axes.forEach(a => {
        const d = a.dot(rotationAxis);
        if (d > maxDot) {
          maxDot = d;
          bestAxis = a;
        }
      });

      const cubiePos = new THREE.Vector3(...cubie.position);
      const layer = Math.round(cubiePos.dot(bestAxis));

      const tangent = new THREE.Vector3().crossVectors(bestAxis, faceNormal).normalize();
      const isClockwise = worldMoveDir.dot(tangent) < 0;

      rotateFace(bestAxis, layer, isClockwise);
    };

    window.addEventListener('pointerup', onPointerUpWindow);
  };

  // Scramble logic
  useEffect(() => {
    if (scrambleTrigger === 0) return;
    
    const axes = [new THREE.Vector3(1,0,0), new THREE.Vector3(0,1,0), new THREE.Vector3(0,0,1)];
    const layers = [-1, 0, 1];
    let count = 0;
    const maxMoves = 20;
    
    const interval = setInterval(() => {
      const randomAxis = axes[Math.floor(Math.random() * axes.length)];
      const randomLayer = layers[Math.floor(Math.random() * layers.length)];
      rotateFace(randomAxis, randomLayer, Math.random() > 0.5);
      count++;
      if (count >= maxMoves) clearInterval(interval);
    }, 400);

    return () => clearInterval(interval);
  }, [scrambleTrigger]);

  // Reset logic
  useEffect(() => {
    if (resetTrigger === 0) return;
    setCubies(() => {
      const initial: CubieState[] = [];
      for (let x = -1; x <= 1; x++) {
        for (let y = -1; y <= 1; y++) {
          for (let z = -1; z <= 1; z++) {
            if (x === 0 && y === 0 && z === 0) continue;
            initial.push({
              position: [x, y, z] as [number, number, number],
              initialPosition: [x, y, z] as [number, number, number],
              rotation: new THREE.Quaternion(),
              id: `${x}${y}${z}`,
            });
          }
        }
      }
      return initial;
    });
  }, [resetTrigger]);

  return (
    <group onPointerDown={handlePointerDown}>
      {cubies.map((cubie) => {
        const isRotating = activeRotation && Math.abs(new THREE.Vector3(...cubie.position).dot(activeRotation.axis) - activeRotation.layer) < 0.1;
        
        let visualPosition = new THREE.Vector3(...cubie.position);
        let visualRotation = cubie.rotation;
        
        if (isRotating && activeRotation) {
          const animationRot = new THREE.Quaternion().setFromAxisAngle(activeRotation.axis, activeRotation.angle);
          visualPosition.applyQuaternion(animationRot);
          visualRotation = animationRot.clone().multiply(cubie.rotation);
        }

        return (
          <group 
            key={cubie.id} 
            position={visualPosition} 
            rotation={new THREE.Euler().setFromQuaternion(visualRotation)}
            userData={{ id: cubie.id }}
          >
            <Cubie initialPosition={cubie.initialPosition} />
          </group>
        );
      })}
    </group>
  );
};

export default function App() {
  const orbitRef = useRef<any>(null);
  const [scrambleCount, setScrambleCount] = useState(0);
  const [resetCount, setResetCount] = useState(0);
  const [moves, setMoves] = useState(0);
  const [isSolved, setIsSolved] = useState(false);
  const [azimuth, setAzimuth] = useState(0);
  const [polar, setPolar] = useState(Math.PI / 4);

  const handleScramble = () => {
    setScrambleCount(prev => prev + 1);
    setMoves(0);
  };

  const handleReset = () => {
    setResetCount(prev => prev + 1);
    setMoves(0);
  };

  return (
    <div className="relative w-full h-screen bg-[#0a0a0a] text-white font-sans overflow-hidden">
      {/* Background Atmosphere */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-[-10%] left-[-10%] w-[40%] h-[40%] bg-blue-500/10 blur-[120px] rounded-full" />
        <div className="absolute bottom-[-10%] right-[-10%] w-[40%] h-[40%] bg-red-500/10 blur-[120px] rounded-full" />
      </div>

      {/* Header */}
      <header className="absolute top-0 left-0 w-full p-8 flex justify-between items-start z-10">
        <motion.div 
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="flex flex-col"
        >
          <h1 className="text-4xl font-black tracking-tighter uppercase italic">
            Rubix<span className="text-blue-500">.</span>
          </h1>
          <p className="text-xs font-mono text-white/40 tracking-widest uppercase mt-1">
            Interactive 3D Simulation
          </p>
        </motion.div>

        <motion.div 
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          className="flex gap-4"
        >
          <div className="bg-white/5 backdrop-blur-md border border-white/10 rounded-2xl p-4 flex flex-col items-center min-w-[100px]">
            <span className="text-[10px] font-mono text-white/40 uppercase tracking-widest">Moves</span>
            <span className="text-2xl font-bold">{moves}</span>
          </div>
        </motion.div>
      </header>

      {/* Main Canvas */}
      <div className="w-full h-full cursor-grab active:cursor-grabbing">
        <Canvas shadows dpr={[1, 2]}>
          <PerspectiveCamera makeDefault position={[5, 5, 5]} fov={45} />
          <OrbitControls 
            ref={orbitRef}
            enablePan={false} 
            minDistance={4} 
            maxDistance={10} 
            makeDefault
            autoRotate={false}
            enableDamping
            dampingFactor={0.05}
            onChange={() => {
              if (orbitRef.current) {
                setAzimuth(orbitRef.current.getAzimuthalAngle());
                setPolar(orbitRef.current.getPolarAngle());
              }
            }}
          />
          
          <ambientLight intensity={0.5} />
          <pointLight position={[10, 10, 10]} intensity={1} castShadow />
          <spotLight position={[-10, 10, 10]} angle={0.15} penumbra={1} intensity={1} />
          
          <RubiksCube 
            scrambleTrigger={scrambleCount} 
            resetTrigger={resetCount}
            onMove={() => setMoves(m => m + 1)}
            onSolved={setIsSolved}
            orbitRef={orbitRef}
          />

          <Environment preset="city" />
          <ContactShadows position={[0, -2.5, 0]} opacity={0.4} scale={10} blur={2} far={4.5} />
        </Canvas>
      </div>

      {/* Controls Footer */}
      <footer className="absolute bottom-0 left-0 w-full p-8 flex justify-center items-end z-10 pointer-events-none">
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-white/5 backdrop-blur-xl border border-white/10 rounded-3xl p-2 flex gap-2 pointer-events-auto shadow-2xl"
        >
          <button 
            onClick={handleScramble}
            className="flex items-center gap-2 px-6 py-3 bg-white text-black rounded-2xl font-bold hover:bg-blue-500 hover:text-white transition-all group"
          >
            <Shuffle size={18} className="group-hover:rotate-180 transition-transform duration-500" />
            Scramble
          </button>
          
          <button 
            onClick={handleReset}
            className="flex items-center gap-2 px-6 py-3 bg-white/10 text-white rounded-2xl font-bold hover:bg-white/20 transition-all"
          >
            <RotateCcw size={18} />
            Reset
          </button>

          <div className="w-px h-12 bg-white/10 mx-2 self-center" />

          <button className="p-3 text-white/40 hover:text-white transition-colors">
            <HelpCircle size={20} />
          </button>
          <button className="p-3 text-white/40 hover:text-white transition-colors">
            <Settings2 size={20} />
          </button>
        </motion.div>
      </footer>

      {/* Sliders Overlay */}
      <div className="absolute right-12 top-1/2 -translate-y-1/2 flex flex-col gap-12 z-20">
        <div className="flex flex-col items-center gap-6">
          <span className="text-[10px] font-mono text-white/40 uppercase tracking-[0.3em] [writing-mode:vertical-lr] rotate-180">Vertical View</span>
          <div className="relative h-48 w-6 flex items-center justify-center">
            <input 
              type="range" 
              min={0.1} 
              max={Math.PI - 0.1} 
              step={0.01}
              value={polar}
              onChange={(e) => {
                const val = parseFloat(e.target.value);
                setPolar(val);
                if (orbitRef.current) {
                  orbitRef.current.setPolarAngle(val);
                  orbitRef.current.update();
                }
              }}
              className="absolute h-48 w-1 appearance-none bg-white/10 rounded-full outline-none cursor-pointer accent-blue-500 hover:bg-white/20 transition-colors"
              style={{ WebkitAppearance: 'slider-vertical' } as any}
            />
          </div>
        </div>
      </div>

      <div className="absolute bottom-32 left-12 w-64 flex flex-col items-start gap-4 z-20">
        <div className="relative w-full h-6 flex items-center justify-start">
          <input 
            type="range" 
            min={-Math.PI} 
            max={Math.PI} 
            step={0.01}
            value={azimuth}
            onChange={(e) => {
              const val = parseFloat(e.target.value);
              setAzimuth(val);
              if (orbitRef.current) {
                orbitRef.current.setAzimuthalAngle(val);
                orbitRef.current.update();
              }
            }}
            className="w-full h-1 appearance-none bg-white/10 rounded-full outline-none cursor-pointer accent-blue-500 hover:bg-white/20 transition-colors"
          />
        </div>
        <span className="text-[10px] font-mono text-white/40 uppercase tracking-[0.3em]">Horizontal Orbit</span>
      </div>

      {/* Instructions Overlay */}
      <div className="absolute top-20 left-1/2 -translate-x-1/2 text-white/30 text-[10px] uppercase tracking-[0.2em] font-mono text-center pointer-events-none">
        Drag on cube to rotate layers • Drag background to orbit
      </div>

      {/* Solved Message */}
      <AnimatePresence>
        {isSolved && moves > 0 && (
          <motion.div 
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.8 }}
            className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 z-50 pointer-events-none"
          >
            <div className="bg-blue-500 text-white px-12 py-6 rounded-3xl shadow-2xl flex flex-col items-center gap-2 border-4 border-white/20 backdrop-blur-xl">
              <Trophy size={48} className="mb-2" />
              <h2 className="text-4xl font-black uppercase italic tracking-tighter">Solved!</h2>
              <p className="text-sm font-mono opacity-80 uppercase tracking-widest">In {moves} moves</p>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
